from django.shortcuts import render, redirect
from django.http import HttpResponse
from django.views.decorators.csrf import csrf_exempt
from pharmacy_app.repositories import RepositoryFactory
from pharmacy_app.NetworkHelper import ColleagueAPIHelper

# ========== мій ==========

def medicine_list(request):
    """Список ліків"""
    repo = RepositoryFactory.get_medicine_repo()
    medicines = repo.get_all()
    return render(request, 'pharmacy_ui/medicine_list.html', {'medicines': medicines})

def medicine_detail(request, medicine_id):
    """Деталі ліків"""
    repo = RepositoryFactory.get_medicine_repo()
    medicine = repo.get_by_id(medicine_id)
    if not medicine:
        return render(request, 'pharmacy_ui/medicine_not_found.html', {'medicine_id': medicine_id})
    return render(request, 'pharmacy_ui/medicine_detail.html', {'medicine': medicine})

def medicine_create(request):
    """Форма для додавання нових ліків з полем-зв'язком (постачальник)"""
    if request.method == 'POST':
        repo = RepositoryFactory.get_medicine_repo()
        
        medicine_name = request.POST.get('medicine_name', '').strip()
        price = request.POST.get('price', '').strip()
        supplier_name = request.POST.get('supplier_name', '').strip()
        
        if not medicine_name or not price:
            return render(request, 'pharmacy_ui/medicine_form.html', {
                'error': 'Назва та ціна обов\'язкові!',
                'form_data': request.POST,
                'selected_supplier': supplier_name
            })
        
        try:
            medicine_data = {
                'medicine_name': medicine_name,
                'category': request.POST.get('category', '').strip(),
                'manufacturer': request.POST.get('manufacturer', '').strip(),
                'price': float(price),
                'quantity_in_stock': int(request.POST.get('quantity_in_stock', 0)),
                'prescription_required': 'prescription_required' in request.POST,
            }
            
            if supplier_name:
                medicine_data['supplier_info'] = supplier_name
            
            new_medicine = repo.create(**medicine_data)
            
            return redirect('medicine_detail', medicine_id=new_medicine.medicine_id)
            
        except ValueError as e:
            return render(request, 'pharmacy_ui/medicine_form.html', {
                'error': f'Невірний формат даних: {e}',
                'form_data': request.POST,
                'selected_supplier': supplier_name
            })
        except Exception as e:
            return render(request, 'pharmacy_ui/medicine_form.html', {
                'error': f'Помилка при створенні: {str(e)}',
                'form_data': request.POST,
                'selected_supplier': supplier_name
            })
    else:
        return render(request, 'pharmacy_ui/medicine_form.html')

def medicine_delete(request, medicine_id):
    """Видалення ліків"""
    repo = RepositoryFactory.get_medicine_repo()
    medicine = repo.get_by_id(medicine_id)
    if not medicine:
        return redirect('medicine_list')
    
    if request.method == 'POST':
        deleted = repo.delete(medicine_id)
        if deleted:
            return render(request, 'pharmacy_ui/medicine_deleted.html', {
                'medicine_name': medicine.medicine_name,
                'medicine_id': medicine_id
            })
        else:
            return render(request, 'pharmacy_ui/medicine_detail.html', {
                'medicine': medicine,
                'error': 'Не вдалося видалити'
            })
    
    return render(request, 'pharmacy_ui/medicine_confirm_delete.html', {'medicine': medicine})

# ========== кол ==========

def colleague_teams(request):
    """Команди з API колеги"""
    helper = ColleagueAPIHelper()
    raw_teams = helper.get_teams_list()
    
    # Обробка даних команд
    teams = []
    if raw_teams:
        for item in raw_teams:
            team = {
                'id': item.get('team_id'),
                'name': item.get('team_name', 'Без назви'),
                'points': item.get('points', 0),
                'wins': item.get('wins', 0),
                'loses': item.get('loses', 0),
                'draws': item.get('draws', 0),
                'goal_difference': item.get('goal_difference', 0),
            }
            teams.append(team)
    
    return render(request, 'pharmacy_ui/colleague_teams.html', {
        'teams': teams,
        'title': 'Команди з проекту колеги'
    })

def colleague_coaches(request):
    """Тренери з API колеги"""
    helper = ColleagueAPIHelper()
    raw_coaches = helper.get_coaches_list()
    
    # Обробка даних тренерів
    coaches = []
    if raw_coaches:
        for item in raw_coaches:
            coach = {
                'id': item.get('coach_id'),
                'name': item.get('coach_name', 'Без назви'),
                'nationality': item.get('coach_country', 'Не вказано'),
                'experience': item.get('experience', '-'),
            }
            coaches.append(coach)
    
    return render(request, 'pharmacy_ui/colleague_coaches.html', {
        'coaches': coaches,
        'title': 'Тренери з проекту колеги'
    })

@csrf_exempt
def delete_team(request, team_id):
    """Видалити команду через API"""
    if request.method == 'POST':
        helper = ColleagueAPIHelper()
        success = helper.delete_team(team_id)
        
        if success:
            return redirect('colleague_teams')
        else:
            return HttpResponse("Помилка видалення", status=500)
    
    return HttpResponse("Метод не дозволений", status=405)

@csrf_exempt
def delete_coach(request, coach_id):
    """Видалити тренера через API"""
    if request.method == 'POST':
        helper = ColleagueAPIHelper()
        success = helper.delete_coach(coach_id)
        
        if success:
            return redirect('colleague_coaches')
        else:
            return HttpResponse("Помилка видалення тренера", status=500)
    
    return HttpResponse("Метод не дозволений", status=405)