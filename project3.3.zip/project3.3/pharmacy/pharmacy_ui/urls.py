from django.urls import path
from . import views

urlpatterns = [
    # Власний проект
    path('medicines/', views.medicine_list, name='medicine_list'),
    path('medicines/<int:medicine_id>/', views.medicine_detail, name='medicine_detail'),
    path('medicines/create/', views.medicine_create, name='medicine_create'),
    path('medicines/<int:medicine_id>/delete/', views.medicine_delete, name='medicine_delete'),
    
    # кол
    path('colleague-teams/', views.colleague_teams, name='colleague_teams'),
    path('colleague-coaches/', views.colleague_coaches, name='colleague_coaches'),
    path('delete-team/<int:team_id>/', views.delete_team, name='delete_team'),
    path('delete-coach/<int:coach_id>/', views.delete_coach, name='delete_coach'),
]