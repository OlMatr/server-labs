from django.apps import AppConfig


class PharmacyUiConfig(AppConfig):
    name = 'pharmacy_ui'
