# pharmacy/pharmacy_app/NetworkHelper.py
import requests

class ColleagueAPIHelper:
    def __init__(self, base_url="http://localhost:8001"):
        self.base_url = base_url
        
    def get_coaches_list(self):
        """Отримати список тренерів"""
        try:
            response = requests.get(f"{self.base_url}/api/coach/", timeout=5)
            
            if response.status_code == 200:
                data = response.json()
                print(f"✅ API тренерів: отримано {len(data) if data else 0} записів")
                return data
            else:
                print(f"❌ Помилка API тренерів: {response.status_code}")
                return []
        except Exception as e:
            print(f"❌ Помилка запиту тренерів: {e}")
            return []
        
    def delete_coach(self, coach_id):
        """Видалити тренера"""
        try:
            response = requests.delete(
                f"{self.base_url}/api/coach/{coach_id}/",
                timeout=5
            )
            success = response.status_code == 204
            print(f"🗑️ Видалення тренера {coach_id}: {'✅ Успішно' if success else '❌ Помилка'}")
            return success
        except Exception as e:
            print(f"❌ Помилка видалення тренера: {e}")
            return False
    
    def get_teams_list(self):
        """Отримати список команд"""
        try:
            response = requests.get(f"{self.base_url}/api/teams/", timeout=5)
            
            if response.status_code == 200:
                data = response.json()
                print(f"✅ API команд: отримано {len(data) if data else 0} записів")
                return data
            else:
                print(f"❌ Помилка API команд: {response.status_code}")
                return []
        except Exception as e:
            print(f"❌ Помилка запиту команд: {e}")
            return []
    
    def delete_team(self, team_id):
        """Видалити команду"""
        try:
            response = requests.delete(
                f"{self.base_url}/api/teams/{team_id}/",
                timeout=5
            )
            success = response.status_code == 204
            print(f"🗑️ Видалення команди {team_id}: {'✅ Успішно' if success else '❌ Помилка'}")
            return success
        except Exception as e:
            print(f"❌ Помилка видалення: {e}")
            return False