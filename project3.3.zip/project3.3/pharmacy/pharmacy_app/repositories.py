from abc import ABC, abstractmethod
from typing import List, TypeVar, Generic, Optional, Type, Any
from django.db import models, transaction

from django.db.models import Sum, Count, Avg, F, Q, DecimalField, ExpressionWrapper
from django.db.models.functions import Coalesce, TruncMonth, TruncYear, ExtractMonth, ExtractYear
from django.db import models
import datetime



T = TypeVar('T', bound=models.Model)

# ІНТ РЕПОЗИТОРІЮ
class IRepository(Generic[T], ABC):
    @abstractmethod
    def get_all(self) -> List[T]:
        pass
    
    @abstractmethod
    def get_by_id(self, id: int) -> Optional[T]:
        pass
    
    @abstractmethod
    def create(self, **kwargs) -> T:
        pass
    
    @abstractmethod
    def update(self, id: int, **kwargs) -> Optional[T]:
        pass
    
    @abstractmethod
    def delete(self, id: int) -> bool:
        pass


class BaseRepository(IRepository[T]):
    def __init__(self, model_class: Type[T]):
        self.model_class = model_class
    
    def get_all(self) -> List[T]:
        try:
            return list(self.model_class.objects.all())
        except Exception as e:
            print(f"Помилка отримання всіх {self.model_class.__name__}: {e}")
            return []
    
    def get_by_id(self, id: int) -> Optional[T]:
        try:
            return self.model_class.objects.get(id=id)
        except (self.model_class.DoesNotExist, Exception):
            try:
                return self.model_class.objects.get(medicine_id=id)
            except self.model_class.DoesNotExist:
                print(f"{self.model_class.__name__} з ID {id} не знайдено")
                return None
            except Exception as e:
                print(f"Помилка отримання {self.model_class.__name__}: {e}")
                return None
    
    def create(self, **kwargs) -> T:
        try:
            with transaction.atomic():
                return self.model_class.objects.create(**kwargs)
        except Exception as e:
            print(f"Помилка створення {self.model_class.__name__}: {e}")
            raise
    
    def update(self, id: int, **kwargs) -> Optional[T]:
        try:
            instance = self.get_by_id(id)
            if instance:
                for key, value in kwargs.items():
                    setattr(instance, key, value)
                instance.save()
                return instance
            return None
        except Exception as e:
            print(f"Помилка оновлення {self.model_class.__name__}: {e}")
            return None
    
    def delete(self, id: int) -> bool:
        try:
            instance = self.get_by_id(id)
            if instance:
                instance.delete()
                return True
            return False
        except Exception as e:
            print(f"Помилка видалення {self.model_class.__name__}: {e}")
            return False
    
    def filter(self, **kwargs) -> List[T]:
        try:
            return list(self.model_class.objects.filter(**kwargs))
        except Exception as e:
            print(f"Помилка фільтрації {self.model_class.__name__}: {e}")
            return []


# РЕПОЗИТОРІЇ
from .models import Medicine, Customer, Pharmacist

class MedicineRepository(BaseRepository):
    def __init__(self):
        super().__init__(Medicine)
    
    def get_medicines_by_category(self, category: str) -> List[Medicine]:
        return self.filter(category=category)
    
    def get_medicines_need_prescription(self) -> List[Medicine]:
        return self.filter(prescription_required=True)

    def get_top_selling_medicines(self, limit=5):
        """Топ-N ліків за кількістю проданих одиниць"""
        from .models import SaleDetails
        
        return SaleDetails.objects.values(
            'medicine__medicine_id',
            'medicine__medicine_name',
            'medicine__category'
        ).annotate(
            total_sold=Sum('quantity'),
            total_revenue=Sum(F('quantity') * F('price_per_unit')),
            sale_count=Count('sale', distinct=True)
        ).order_by('-total_sold')[:limit]
    
    def get_category_sales_stats(self):
        """Статистика продажів по категоріях"""
        from .models import SaleDetails
        
        return SaleDetails.objects.values(
            'medicine__category'
        ).annotate(
            total_units_sold=Sum('quantity'),
            total_revenue=Sum(F('quantity') * F('price_per_unit')),
            avg_price=Avg('price_per_unit'),
            unique_medicines=Count('medicine', distinct=True)
        ).filter(total_units_sold__gt=0).order_by('-total_revenue')
    
    def get_monthly_sales_trend(self, year=None):
        """Продажі по місяцях - ВИПРАВЛЕНО!"""
        from .models import Sale
        
        queryset = Sale.objects.all()
        
        if year:
            queryset = queryset.filter(sale_date__year=year)
        
        # Виправлений запит
        return queryset.annotate(
            month=TruncMonth('sale_date'),
            year=TruncYear('sale_date')
        ).values('year', 'month').annotate(
            total_sales=Count('sale_id'),
            total_amount=Sum('total_amount'),
            # avg_sale_amount вираховуємо окремо
        ).order_by('year', 'month')
    
    def get_customers_with_high_value_orders(self, min_amount=1000):
        """Клієнти з загальною сумою покупок > N"""
        from .models import Sale, Customer
        
        return Customer.objects.annotate(
            total_spent=Sum('sale__total_amount'),
            order_count=Count('sale', distinct=True)
        ).filter(
            total_spent__gt=min_amount,
            order_count__gt=0
        ).order_by('-total_spent')
    
    def get_medicines_low_stock_high_demand(self, stock_threshold=10):
        """Ліки з низьким запасом але високим попитом"""
        from .models import Medicine
        
        # Спрощений запит без фільтра по даті
        return Medicine.objects.filter(
            quantity_in_stock__lt=stock_threshold
        ).annotate(
            total_sold=Coalesce(
                Sum('saledetails__quantity'), 
                0
            )
        ).filter(total_sold__gt=0).order_by('-total_sold', 'quantity_in_stock')
    
    def get_supplier_performance_stats(self):
        """Статистика постачальників"""
        from .models import Supplier
        
        return Supplier.objects.annotate(
            total_deliveries=Count('delivery', distinct=True),
            total_spent=Sum('delivery__total_cost'),
            avg_delivery_value=Avg('delivery__total_cost')
        ).filter(total_deliveries__gt=0).order_by('-total_spent')

class CustomerRepository(BaseRepository):
    def __init__(self):
        super().__init__(Customer)
    
    def get_customers_with_discount(self) -> List[Customer]:
        return self.filter(discount_card=True)
    
    def get_customer_by_phone(self, phone: str) -> Optional[Customer]:
        customers = self.filter(phone=phone)
        return customers[0] if customers else None


class PharmacistRepository(BaseRepository):
    def __init__(self):
        super().__init__(Pharmacist)
    
    def get_pharmacists_by_position(self, position: str) -> List[Pharmacist]:
        return self.filter(position=position)


# ЄДИНА ТОЧКА ДОСТУПУ
class RepositoryFactory:
    @staticmethod
    def get_medicine_repo() -> MedicineRepository:
        return MedicineRepository()
    
    @staticmethod
    def get_customer_repo() -> CustomerRepository:
        return CustomerRepository()
    
    @staticmethod
    def get_pharmacist_repo() -> PharmacistRepository:
        return PharmacistRepository()