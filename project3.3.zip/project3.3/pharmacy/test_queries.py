import os
import sys

sys.path.append(os.path.dirname(os.path.abspath(__file__)))
os.environ.setdefault('DJANGO_SETTINGS_MODULE', 'pharmacy.settings')

import django
django.setup()

from pharmacy_app.models import Medicine, Sale, SaleDetails, Customer, Supplier
from django.db.models import Sum, Count, Avg, F, Q
from django.db.models.functions import Coalesce, TruncMonth, TruncYear
from django.db import models

class TestQueriesFixed:
    
    @staticmethod
    def get_top_selling_medicines(limit=5):
        return SaleDetails.objects.values(
            'medicine__medicine_id',
            'medicine__medicine_name',
            'medicine__category'
        ).annotate(
            total_sold=Sum('quantity'),
            total_revenue=Sum(F('quantity') * F('price_per_unit')),
            sale_count=Count('sale')
        ).order_by('-total_sold')[:limit]
    
    @staticmethod
    def get_category_sales_stats():
        return SaleDetails.objects.values(
            'medicine__category'
        ).annotate(
            total_units_sold=Sum('quantity'),
            total_revenue=Sum(F('quantity') * F('price_per_unit')),
            avg_price=Avg('price_per_unit'),
            unique_medicines=Count('medicine', distinct=True)
        ).filter(total_units_sold__gt=0).order_by('-total_revenue')
    
    @staticmethod
    def get_monthly_sales_trend(year=None):
        queryset = Sale.objects.all()
        
        if year:
            queryset = queryset.filter(sale_date__year=year)
        
        return queryset.annotate(
            month=TruncMonth('sale_date')
        ).values('month').annotate(
            total_sales=Count('sale_id'),
            total_amount=Sum('total_amount')
        ).order_by('month')
    
    @staticmethod
    def get_customers_with_high_value_orders(min_amount=1000):
        return Customer.objects.annotate(
            total_spent=Sum('sale__total_amount'),
            order_count=Count('sale')
        ).filter(
            total_spent__gt=min_amount,
            order_count__gt=0
        ).order_by('-total_spent')
    
    @staticmethod
    def get_medicines_low_stock_high_demand(stock_threshold=10):
        return Medicine.objects.filter(
            quantity_in_stock__lt=stock_threshold
        ).annotate(
            total_sold=Coalesce(
                Sum('saledetails__quantity'), 
                0
            )
        ).filter(total_sold__gt=0).order_by('-total_sold', 'quantity_in_stock')
    
    @staticmethod
    def get_supplier_performance_stats():
        return Supplier.objects.annotate(
            total_deliveries=Count('delivery'),
            total_spent=Sum('delivery__total_cost'),
            avg_delivery_value=Avg('delivery__total_cost')
        ).filter(total_deliveries__gt=0).order_by('-total_spent')

def test_all_queries():
    print("="*60)
    print("ТЕСТУВАННЯ 6 СКЛАДНИХ ЗАПИТІВ ORM (ВИПРАВЛЕНО)")
    print("="*60)
    
    # 1. Топ-5 ліків за продажами
    print("\n1. 📊 Топ-3 найпопулярніших ліків:")
    top_medicines = TestQueriesFixed.get_top_selling_medicines(3)
    if top_medicines:
        for i, med in enumerate(top_medicines, 1):
            name = med.get('medicine__medicine_name', 'Невідомо')
            category = med.get('medicine__category', 'Невідомо')
            sold = med.get('total_sold', 0)
            revenue = med.get('total_revenue', 0)
            print(f"   {i}. {name}")
            print(f"      Категорія: {category}")
            print(f"      Продано: {sold} од.")
            print(f"      Дохід: {revenue:.2f} грн")
            print()
    else:
        print("   ❌ Немає даних про продажі")
    
    # 2. Статистика по категоріях
    print("\n2. 📈 Статистика продажів по категоріях:")
    category_stats = TestQueriesFixed.get_category_sales_stats()
    if category_stats:
        for cat in category_stats:
            category = cat.get('medicine__category', 'Невідомо')
            units = cat.get('total_units_sold', 0)
            revenue = cat.get('total_revenue', 0)
            avg_price = cat.get('avg_price', 0)
            unique = cat.get('unique_medicines', 0)
            
            print(f"   📦 Категорія: {category}")
            print(f"      Продано: {units} од.")
            print(f"      Дохід: {revenue:.2f} грн")
            print(f"      Середня ціна: {avg_price:.2f} грн")
            print(f"      Унікальних ліків: {unique}")
            print()
    else:
        print("   ❌ Немає даних по категоріям")
    
    # 3. Місячний тренд (ВИПРАВЛЕНО)
    print("\n3. 📅 Продажі по місяцях (2024):")
    try:
        monthly = TestQueriesFixed.get_monthly_sales_trend(2024)
        if monthly:
            for month in monthly:
                month_str = month.get('month', 'Невідомо')
                sales = month.get('total_sales', 0)
                amount = month.get('total_amount', 0)
                
                print(f"   🗓️  {month_str}:")
                print(f"      Продажі: {sales} шт.")
                print(f"      Сума: {amount:.2f} грн")
                if sales > 0:
                    avg = amount / sales
                    print(f"      Середній чек: {avg:.2f} грн")
        else:
            print("   ℹ️ Немає продажів у 2025 році")
    except Exception as e:
        print(f"   ❌ Помилка: {e}")
    
    # 4. Клієнти з великими покупками
    print("\n4. 👥 Клієнти з покупками > 100 грн:")
    big_customers = TestQueriesFixed.get_customers_with_high_value_orders(100)
    if big_customers:
        for cust in big_customers:
            print(f"   👤 {cust.name}:")
            print(f"      Витрати: {cust.total_spent:.2f} грн")
            print(f"      Кількість замовлень: {cust.order_count}")
    else:
        print("   ℹ️ Немає клієнтів з покупками > 1000 грн")
    
    # 5. Ліки з низьким запасом
    print("\n5. ⚠️  Ліки з низьким запасом (<10) але попитом:")
    low_stock = TestQueriesFixed.get_medicines_low_stock_high_demand(5)
    if low_stock:
        for med in low_stock:
            print(f"   💊 {med.medicine_name}:")
            print(f"      На складі: {med.quantity_in_stock} од.")
            print(f"      Загалом продано: {med.total_sold} од.")
            print(f"      Категорія: {med.category}")
    else:
        print("   ✅ У всіх ліків достатній запас або немає продажів")
    
    # 6. Постачальники
    print("\n6. 🚚 Статистика постачальників:")
    suppliers = TestQueriesFixed.get_supplier_performance_stats()
    if suppliers:
        for sup in suppliers:
            print(f"   🏢 {sup.name}:")
            print(f"      Поставок: {sup.total_deliveries}")
            print(f"      Витрачено: {sup.total_spent:.2f} грн" if sup.total_spent else "      Витрачено: 0.00 грн")
            print(f"      Середня поставка: {sup.avg_delivery_value:.2f} грн" if sup.avg_delivery_value else "      Середня поставка: 0.00 грн")
    else:
        print("   ℹ️ Немає даних про постачальників")
    
    print("\n" + "="*60)
    print("✅ ТЕСТ ЗАВЕРШЕНО")
    print("="*60)

if __name__ == "__main__":
    test_all_queries()